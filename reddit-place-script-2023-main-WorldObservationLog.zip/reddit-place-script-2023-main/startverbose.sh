pip3 install -r requirements.txt
python3 main.py --debug
